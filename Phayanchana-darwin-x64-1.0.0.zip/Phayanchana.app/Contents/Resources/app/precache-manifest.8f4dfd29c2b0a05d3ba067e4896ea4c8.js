self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2e2e1f76d5c03ef4846c93775181512f",
    "url": "./index.html"
  },
  {
    "revision": "37c61d30e9b406971540",
    "url": "./static/css/2.2ce0d9b2.chunk.css"
  },
  {
    "revision": "9d9a120296ce70937e8f",
    "url": "./static/css/main.b84406f8.chunk.css"
  },
  {
    "revision": "37c61d30e9b406971540",
    "url": "./static/js/2.3403dda2.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.3403dda2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9d9a120296ce70937e8f",
    "url": "./static/js/main.764c88d7.chunk.js"
  },
  {
    "revision": "74eb79e5b1682c233acf",
    "url": "./static/js/runtime-main.bafcb5c9.js"
  },
  {
    "revision": "20c8f9ec2584d85bd116e6e00734dc74",
    "url": "./static/media/Thai-Font.20c8f9ec.ttf"
  },
  {
    "revision": "7ddd694ccdde730b6da67687e3e1c87f",
    "url": "./static/media/flowers.7ddd694c.png"
  },
  {
    "revision": "48701df7486bab693bdef814d52fb99f",
    "url": "./static/media/trees.48701df7.png"
  }
]);